<footer class="blockquote-footer" style="text-align: center;">
    <div class="copyright">
        &copy; Desenvolvido por Maxsandro Sarat. Todos os direitos reservados.
    </div>
</footer>